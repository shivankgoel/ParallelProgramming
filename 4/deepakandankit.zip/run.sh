mpirun -n 48 ./main < $1 > $2
